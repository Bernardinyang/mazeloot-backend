<?php

use App\Http\Controllers\V1\AuthController;
use App\Http\Controllers\V1\CacheController;
use App\Http\Controllers\V1\ContactController;
use App\Http\Controllers\V1\EarlyAccessController;
use App\Http\Controllers\V1\ImageUploadController;
use App\Http\Controllers\V1\Memora\SubscriptionController;
use App\Http\Controllers\V1\NotificationController;
use App\Http\Controllers\V1\OnboardingController;
use App\Http\Controllers\V1\PricingController;
use App\Http\Controllers\V1\ProductController;
use App\Http\Controllers\V1\ProductSelectionController;
use App\Http\Controllers\V1\ReferralController;
use App\Http\Controllers\V1\UploadController;
use App\Http\Controllers\V1\Webhooks\FlutterwaveWebhookController;
use App\Http\Controllers\V1\Webhooks\PayPalWebhookController;
use App\Http\Controllers\V1\Webhooks\PaystackWebhookController;
use App\Http\Controllers\V1\Webhooks\StripeWebhookController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes - Version 1
|--------------------------------------------------------------------------
|
| Version 1 of the API routes. All routes here are prefixed with /api/v1
|
*/

// Cache management routes (public but protected by secret token)
Route::prefix('cache')->group(function () {
    Route::get('/clear-all', [CacheController::class, 'clearAll']);
});

// Products (public or authenticated)
Route::get('/products', [ProductController::class, 'index']);

// FAQ (public)
Route::get('/faqs', [\App\Http\Controllers\V1\FaqController::class, 'index']);

// Contact form (public)
Route::post('/contact', [ContactController::class, 'submit'])->middleware('throttle:5,60');

// Waitlist (public)
Route::post('/public/waitlist', [\App\Http\Controllers\V1\WaitlistController::class, 'store'])->middleware('throttle:5,60');

// Newsletter (public)
Route::post('/public/newsletter', [\App\Http\Controllers\V1\NewsletterController::class, 'store'])->middleware('throttle:5,60');
Route::get('/public/newsletter/token/{token}', [\App\Http\Controllers\V1\NewsletterController::class, 'getByToken'])->middleware('throttle:10,60');
Route::get('/public/newsletter/unsubscribe/{token}', [\App\Http\Controllers\V1\NewsletterController::class, 'unsubscribe'])->middleware('throttle:10,60');

// Pricing (public)
Route::get('/pricing/tiers', [PricingController::class, 'tiers']);
Route::get('/pricing/currency-rates', [PricingController::class, 'currencyRates']);
Route::get('/pricing/build-your-own', [PricingController::class, 'buildYourOwn']);
Route::get('/pricing/config', [SubscriptionController::class, 'config']);

// Webhooks (public, signature verified in controller)
Route::post('/webhooks/stripe', [StripeWebhookController::class, 'handle']);
Route::post('/webhooks/paypal', [PayPalWebhookController::class, 'handle']);
Route::post('/webhooks/paystack', [PaystackWebhookController::class, 'handle'])->middleware('paystack.webhook.body');
Route::post('/webhooks/flutterwave', [FlutterwaveWebhookController::class, 'handle'])->middleware('flutterwave.webhook.body');

// Token verification (public, but requires valid token)
Route::get('/onboarding/verify-token', [OnboardingController::class, 'verifyToken']);

// Auth routes (public - no authentication required)
Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/verify-email', [AuthController::class, 'verifyEmail']);
    Route::post('/resend-verification', [AuthController::class, 'resendVerification']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/verify-reset-code', [AuthController::class, 'verifyResetCode']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);

    // Magic link routes
    Route::post('/magic-link/send', [AuthController::class, 'sendMagicLink']);
    Route::post('/magic-link/verify', [AuthController::class, 'verifyMagicLink']);

    // OAuth routes
    Route::get('/oauth/{provider}/redirect', [AuthController::class, 'redirectToProvider']);
    Route::get('/oauth/{provider}/callback', [AuthController::class, 'handleProviderCallback']);
});

// Single upload endpoint - supports Sanctum auth
// Note: API key auth middleware (ApiKeyAuth) can be added to support programmatic access
Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/auth/user', [AuthController::class, 'user']);
    Route::patch('/auth/user', [AuthController::class, 'updateProfile']);
    Route::post('/auth/change-password', [AuthController::class, 'changePassword']);
    Route::post('/auth/account/send-deletion-code', [AuthController::class, 'sendDeletionCode'])->middleware('throttle:3,15');
    Route::delete('/auth/account', [AuthController::class, 'deleteAccount']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::get('/auth/storage', [AuthController::class, 'storage']);
    Route::get('/referral', [ReferralController::class, 'index']);
    Route::get('/referral/list', [ReferralController::class, 'referrals']);
    Route::post('/referral/invite', [ReferralController::class, 'sendInvite'])->middleware('throttle:10,60');
    Route::post('/uploads', [UploadController::class, 'upload']);
    Route::post('/images/upload', [ImageUploadController::class, 'upload']);

    // Notifications
    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class, 'index']);
        Route::get('/unread-count', [NotificationController::class, 'unreadCount']);
        Route::patch('/{id}/read', [NotificationController::class, 'markAsRead']);
        Route::patch('/read-all', [NotificationController::class, 'markAllAsRead']);
        Route::delete('/{id}', [NotificationController::class, 'destroy']);
    });

    // Product selection (must be before /products/{slug} to avoid route conflict)
    Route::prefix('products')->group(function () {
        Route::get('/selected', [ProductSelectionController::class, 'index']);
        Route::post('/select', [ProductSelectionController::class, 'store']);
    });

    // Onboarding
    Route::prefix('onboarding')->group(function () {
        Route::post('/token', [OnboardingController::class, 'generateToken']);
        Route::post('/product-selection-token', [OnboardingController::class, 'generateProductSelectionToken']);
        Route::get('/status', [OnboardingController::class, 'getStatus']);
        Route::post('/step', [OnboardingController::class, 'completeStep']);
        Route::post('/complete', [OnboardingController::class, 'complete']);

        // Memora-specific onboarding helpers
        Route::post('/memora/validate-domain', [OnboardingController::class, 'validateDomain']);
    });

    // Early Access
    Route::prefix('early-access')->group(function () {
        Route::post('/request', [EarlyAccessController::class, 'requestEarlyAccess'])->middleware('throttle:3,1440');
        Route::get('/request/status', [EarlyAccessController::class, 'getRequestStatus']);
        Route::get('/features', [EarlyAccessController::class, 'getAvailableFeatures']);
        Route::get('/features/{feature}', [EarlyAccessController::class, 'checkFeature']);
    });
});

// Products by slug (must be after /products/selected to avoid route conflict)
Route::get('/products/{slug}', [ProductController::class, 'show']);

// Domain routes
// Public routes (loaded first - no authentication required)
require __DIR__.'/../domains/memora/public.php';
// Authenticated routes (require authentication)
require __DIR__.'/../domains/memora/selections.php';
require __DIR__.'/../domains/memora/raw-files.php';
require __DIR__.'/../domains/memora/memora.php';
// Admin routes (require authentication and admin role)
require __DIR__.'/../domains/memora/admin.php';
require __DIR__.'/v1/admin.php';
