<?php

use App\Domains\Memora\Controllers\V1\ClosureRequestController;
use App\Domains\Memora\Controllers\V1\CollectionController;
use App\Domains\Memora\Controllers\V1\CoverLayoutController;
use App\Domains\Memora\Controllers\V1\CoverStyleController;
use App\Domains\Memora\Controllers\V1\DashboardController;
use App\Domains\Memora\Controllers\V1\EmailNotificationController;
use App\Domains\Memora\Controllers\V1\MediaController;
use App\Domains\Memora\Controllers\V1\MediaSetController;
use App\Domains\Memora\Controllers\V1\PresetController;
use App\Domains\Memora\Controllers\V1\ProjectController;
use App\Domains\Memora\Controllers\V1\ProofingApprovalRequestController;
use App\Domains\Memora\Controllers\V1\ProofingController;
use App\Domains\Memora\Controllers\V1\SearchController;
use App\Domains\Memora\Controllers\V1\SettingsController;
use App\Domains\Memora\Controllers\V1\SocialLinkController;
use App\Domains\Memora\Controllers\V1\WatermarkController;
use App\Http\Controllers\V1\Memora\SubscriptionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Memora Domain Routes
|--------------------------------------------------------------------------
|
| Routes for the Memora photo gallery/collections domain
|
*/

Route::middleware(['auth:sanctum'])->prefix('memora')->group(function () {
    // Subscription
    Route::prefix('subscription')->group(function () {
        Route::get('/checkout-options', [SubscriptionController::class, 'checkoutOptions']);
        Route::get('/preview', [SubscriptionController::class, 'preview']);
        Route::get('/order-summary', [SubscriptionController::class, 'orderSummary']);
        Route::post('/checkout', [SubscriptionController::class, 'checkout']);
        Route::post('/complete-test-checkout', [SubscriptionController::class, 'completeTestCheckout']);
        Route::post('/portal', [SubscriptionController::class, 'portal']);
        Route::get('/status', [SubscriptionController::class, 'status']);
        Route::get('/my-plan-requests', [SubscriptionController::class, 'myPlanRequests']);
        Route::get('/pending-checkout', [SubscriptionController::class, 'pendingCheckout']);
        Route::get('/can-downgrade', [SubscriptionController::class, 'canDowngrade']);
        Route::post('/cancel', [SubscriptionController::class, 'cancel']);
        Route::post('/request-downgrade', [SubscriptionController::class, 'requestDowngrade']);
        Route::post('/request-upgrade', [SubscriptionController::class, 'requestUpgrade']);
        Route::get('/downgrade-by-token', [SubscriptionController::class, 'downgradeByToken']);
        Route::post('/confirm-downgrade', [SubscriptionController::class, 'confirmDowngrade']);
        Route::get('/history', [SubscriptionController::class, 'history']);
        Route::get('/usage', [SubscriptionController::class, 'usage']);
    });

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'stats']);

    // Unified Search
    Route::get('/search', [SearchController::class, 'search']);

    // Proofing (unified routes - requires proofing feature)
    Route::middleware(['memora.feature:proofing'])->group(function () {
        Route::get('/proofing', [ProofingController::class, 'index']);
        Route::post('/proofing', [ProofingController::class, 'store']);
        Route::get('/proofing/{id}', [ProofingController::class, 'show']);
        Route::get('/proofing/{id}/storage', [ProofingController::class, 'storage']);
        Route::patch('/proofing/{id}', [ProofingController::class, 'update']);
        Route::delete('/proofing/{id}', [ProofingController::class, 'destroy']);
        Route::post('/proofing/{id}/publish', [ProofingController::class, 'publish']);
        Route::post('/proofing/{id}/star', [ProofingController::class, 'toggleStar']);
        Route::post('/proofing/{id}/duplicate', [ProofingController::class, 'duplicate']);
        Route::post('/proofing/{id}/cover-photo', [ProofingController::class, 'setCoverPhoto']);
        Route::post('/proofing/{id}/recover', [ProofingController::class, 'recover']);
        Route::post('/proofing/{id}/revisions', [ProofingController::class, 'uploadRevision']);
        Route::post('/proofing/{id}/complete', [ProofingController::class, 'complete']);
        Route::post('/proofing/{id}/move-to-collection', [ProofingController::class, 'moveToCollection']);

        Route::post('/closure-requests', [ClosureRequestController::class, 'store']);
        Route::post('/closure-requests/{uuid}/resend', [ClosureRequestController::class, 'resend']);
        Route::post('/closure-requests/{uuid}/cancel', [ClosureRequestController::class, 'cancel']);
        Route::get('/media/{mediaId}/closure-requests', [ClosureRequestController::class, 'getByMedia']);

        Route::post('/approval-requests', [ProofingApprovalRequestController::class, 'store']);
        Route::get('/media/{mediaId}/approval-requests', [ProofingApprovalRequestController::class, 'getByMedia']);

        Route::prefix('proofing/{proofingId}/sets')->group(function () {
            Route::get('/', [MediaSetController::class, 'indexForProofing']);
            Route::post('/', [MediaSetController::class, 'storeForProofing']);
            Route::get('/{id}', [MediaSetController::class, 'showForProofing']);
            Route::patch('/{id}', [MediaSetController::class, 'updateForProofing']);
            Route::delete('/{id}', [MediaSetController::class, 'destroyForProofing']);
            Route::post('/reorder', [MediaSetController::class, 'reorderForProofing']);

            Route::prefix('{setId}/media')->group(function () {
                Route::get('/', [MediaController::class, 'getSetMedia']);
                Route::post('/', [MediaController::class, 'uploadToSet']);
                Route::post('/move', [MediaController::class, 'moveToSet']);
                Route::post('/copy', [MediaController::class, 'copyToSet']);
                Route::patch('/{mediaId}/rename', [MediaController::class, 'rename']);
                Route::patch('/{mediaId}/replace', [MediaController::class, 'replace']);
                Route::post('/{mediaId}/watermark', [MediaController::class, 'applyWatermark']);
                Route::delete('/{mediaId}/watermark', [MediaController::class, 'removeWatermark']);
                Route::post('/{mediaId}/star', [MediaController::class, 'toggleStar']);
                Route::delete('/{mediaId}', [MediaController::class, 'deleteFromSet']);
                Route::post('/{mediaId}/feedback', [MediaController::class, 'addFeedback']);
                Route::patch('/{mediaId}/feedback/{feedbackId}', [MediaController::class, 'updateFeedback']);
                Route::delete('/{mediaId}/feedback/{feedbackId}', [MediaController::class, 'deleteFeedback']);
            });
        });
    });

    // Projects
    Route::prefix('projects')->group(function () {
        Route::get('/', [ProjectController::class, 'index']);
        Route::post('/', [ProjectController::class, 'store']);
        Route::get('/{id}', [ProjectController::class, 'show']);
        Route::patch('/{id}', [ProjectController::class, 'update']);
        Route::delete('/{id}', [ProjectController::class, 'destroy']);
        Route::post('/{id}/star', [ProjectController::class, 'toggleStar']);
        Route::get('/{id}/phases', [ProjectController::class, 'phases']);
    });

    // Collections (unified routes - works for both standalone and project-based)
    // For project-based: pass ?projectId=xxx as query parameter
    Route::get('/collections', [CollectionController::class, 'index']);
    Route::post('/collections', [CollectionController::class, 'store']);
    Route::get('/collections/{id}', [CollectionController::class, 'show']);
    Route::get('/collections/{id}/storage', [CollectionController::class, 'storage']);
    Route::patch('/collections/{id}', [CollectionController::class, 'update']);
    Route::delete('/collections/{id}', [CollectionController::class, 'destroy']);
    Route::post('/collections/{id}/star', [CollectionController::class, 'toggleStar']);
    Route::post('/collections/{id}/duplicate', [CollectionController::class, 'duplicate']);

    // Collection Activities
    Route::prefix('collections/{id}/activities')->group(function () {
        Route::get('/email-registrations', [\App\Domains\Memora\Controllers\V1\CollectionActivityController::class, 'getEmailRegistrations']);
        Route::get('/share-links', [\App\Domains\Memora\Controllers\V1\CollectionActivityController::class, 'getShareLinkActivities']);
        Route::get('/downloads', [\App\Domains\Memora\Controllers\V1\CollectionActivityController::class, 'getDownloadActivities']);
        Route::get('/favourites', [\App\Domains\Memora\Controllers\V1\CollectionActivityController::class, 'getFavouriteActivities']);
        Route::get('/private-photos', [\App\Domains\Memora\Controllers\V1\CollectionActivityController::class, 'getPrivatePhotoActivities']);
    });

    // Media Sets within collections (unified - works for both standalone and project-based)
    // For project-based: pass ?projectId=xxx as query parameter
    Route::prefix('collections/{collectionId}/sets')->group(function () {
        Route::get('/', [MediaSetController::class, 'indexForCollection']);
        Route::post('/', [MediaSetController::class, 'storeForCollection']);
        Route::get('/{id}', [MediaSetController::class, 'showForCollection']);
        Route::patch('/{id}', [MediaSetController::class, 'updateForCollection']);
        Route::delete('/{id}', [MediaSetController::class, 'destroyForCollection']);
        Route::post('/reorder', [MediaSetController::class, 'reorderForCollection']);

        // Media within a set
        Route::prefix('{setId}/media')->group(function () {
            Route::get('/', [MediaController::class, 'getSetMedia']);
            Route::post('/', [MediaController::class, 'uploadToSet']);
            Route::post('/move', [MediaController::class, 'moveToSet']);
            Route::post('/copy', [MediaController::class, 'copyToSet']);
            Route::patch('/{mediaId}/rename', [MediaController::class, 'rename']);
            Route::patch('/{mediaId}/replace', [MediaController::class, 'replace']);
            Route::post('/{mediaId}/watermark', [MediaController::class, 'applyWatermark']);
            Route::delete('/{mediaId}/watermark', [MediaController::class, 'removeWatermark']);
            Route::post('/{mediaId}/star', [MediaController::class, 'toggleStar']);
            Route::delete('/{mediaId}', [MediaController::class, 'deleteFromSet']);
        });
    });

    // MemoraMedia - General operations (not set-specific)
    Route::prefix('media')->group(function () {
        Route::get('/phase/{phaseType}/{phaseId}', [MediaController::class, 'getPhaseMedia']);
        Route::post('/move-between-phases', [MediaController::class, 'moveBetweenPhases']);
        Route::get('/featured', [MediaController::class, 'getFeaturedMedia']);
        Route::get('/user', [MediaController::class, 'getUserMedia']);
        Route::post('/{id}/toggle-featured', [MediaController::class, 'toggleFeatured']);
        Route::post('/{id}/toggle-star', [MediaController::class, 'toggleStarDirect']);
        Route::delete('/{id}', [MediaController::class, 'deleteDirect']);
        Route::get('/{id}/revisions', [MediaController::class, 'getRevisions']);
        Route::get('/{id}', [MediaController::class, 'show']);
    });

    // Settings
    Route::prefix('settings')->group(function () {
        Route::get('/', [SettingsController::class, 'index']);
        Route::patch('/branding', [SettingsController::class, 'updateBranding']);
        Route::patch('/preference', [SettingsController::class, 'updatePreference']);
        Route::patch('/homepage', [SettingsController::class, 'updateHomepage']);
        Route::patch('/email', [SettingsController::class, 'updateEmail']);

        // Email Notifications
        Route::get('/notifications', [EmailNotificationController::class, 'index']);
        Route::get('/notifications/events', [EmailNotificationController::class, 'events']);
        Route::patch('/notifications', [EmailNotificationController::class, 'update']);
        Route::get('/notifications/channels', [EmailNotificationController::class, 'channels']);
        Route::patch('/notifications/channels', [EmailNotificationController::class, 'updateChannels']);

        // Social Links
        Route::prefix('social-links')->group(function () {
            Route::get('/', [SocialLinkController::class, 'index']);
            Route::get('/platforms', [SocialLinkController::class, 'getPlatforms']);
            Route::post('/', [SocialLinkController::class, 'store']);
            Route::patch('/{id}', [SocialLinkController::class, 'update']);
            Route::delete('/{id}', [SocialLinkController::class, 'destroy']);
            Route::post('/reorder', [SocialLinkController::class, 'reorder']);
        });

        // Watermarks (limit enforced per tier in WatermarkService)
        Route::prefix('watermarks')->group(function () {
            Route::get('/', [WatermarkController::class, 'index']);
            Route::post('/', [WatermarkController::class, 'store']);
            Route::post('/upload-image', [WatermarkController::class, 'uploadImage']);
            Route::get('/{id}', [WatermarkController::class, 'show']);
            Route::patch('/{id}', [WatermarkController::class, 'update']);
            Route::delete('/{id}', [WatermarkController::class, 'destroy']);
            Route::post('/{id}/duplicate', [WatermarkController::class, 'duplicate']);
            Route::get('/{id}/usage', [WatermarkController::class, 'usage']);
        });

        // Presets (paid plans only)
        Route::middleware(['memora.not_starter'])->prefix('presets')->group(function () {
            Route::get('/', [PresetController::class, 'index']);
            Route::post('/', [PresetController::class, 'store']);
            Route::patch('/reorder', [PresetController::class, 'reorder']);
            Route::get('/{id}', [PresetController::class, 'show']);
            Route::patch('/{id}', [PresetController::class, 'update']);
            Route::delete('/{id}', [PresetController::class, 'destroy']);
            Route::post('/{id}/duplicate', [PresetController::class, 'duplicate']);
            Route::post('/{id}/apply-to-collection/{collectionId}', [PresetController::class, 'applyToCollection']);
            Route::get('/{id}/usage', [PresetController::class, 'usage']);
            Route::patch('/{id}/set-default', [PresetController::class, 'setDefault']);
        });
    });
});

// Cover Styles - Public endpoints (frontend needs to fetch these)
Route::prefix('cover-styles')->group(function () {
    Route::get('/', [CoverStyleController::class, 'index']);
    Route::get('/{uuid}', [CoverStyleController::class, 'show']);
    Route::get('/slug/{slug}', [CoverStyleController::class, 'showBySlug']);
});

// Cover Layouts - Public endpoints (frontend needs to fetch these)
Route::prefix('cover-layouts')->group(function () {
    Route::get('/', [CoverLayoutController::class, 'index']);
    Route::get('/{uuid}', [CoverLayoutController::class, 'show']);
    Route::get('/slug/{slug}', [CoverLayoutController::class, 'showBySlug']);
});
