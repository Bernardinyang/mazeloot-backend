<?php

namespace App\Domains\Memora\Controllers\V1;

use App\Http\Controllers\Controller as BaseController;

abstract class Controller extends BaseController
{
    //
}
