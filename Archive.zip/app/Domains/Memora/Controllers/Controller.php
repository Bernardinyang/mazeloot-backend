<?php

namespace App\Domains\Memora\Controllers;

use App\Http\Controllers\Controller as BaseController;

abstract class Controller extends BaseController
{
    //
}
