<?php

namespace App\Http\Controllers\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\ImageUploadRequest;
use App\Models\UserFile;
use App\Services\Image\ImageUploadService;
use App\Support\Responses\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ImageUploadController extends Controller
{
    protected ImageUploadService $imageUploadService;

    public function __construct(ImageUploadService $imageUploadService)
    {
        $this->imageUploadService = $imageUploadService;
    }

    /**
     * Upload single or multiple images with automatic variants
     *
     * POST /api/v1/images/upload
     * Supports both 'file' (single) and 'files[]' (multiple) for compatibility
     */
    public function upload(ImageUploadRequest $request): JsonResponse
    {
        // Support both 'file' (single) and 'files' (array) for compatibility
        $files = $request->hasFile('files')
            ? $request->file('files')
            : ($request->hasFile('file') ? [$request->file('file')] : []);

        if (empty($files)) {
            return ApiResponse::error('No files provided', 'NO_FILES', 400);
        }

        // Ensure files is an array
        if (! is_array($files)) {
            $files = [$files];
        }

        $options = [
            'context' => $request->input('context'),
            'visibility' => $request->input('visibility', 'public'),
            'purpose' => $request->input('purpose'),
        ];

        $uploadResults = $this->imageUploadService->uploadMultipleImages($files, $options);
        $userUuid = Auth::user()->uuid;

        // Store files in user_files table and format response
        $results = [];
        foreach ($uploadResults as $index => $uploadResult) {
            $file = $files[$index];
            $purpose = $request->input('purpose');

            // Store file information in user_files table
            $userFile = $this->storeUserFile($userUuid, $file, $uploadResult, $purpose);

            // Format response to match UploadController format, but include variants
            $results[] = [
                'url' => $uploadResult['variants']['original'] ?? $uploadResult['variants']['large'] ?? '',
                'path' => 'uploads/images/'.$uploadResult['uuid'],
                'originalFilename' => $file->getClientOriginalName(),
                'mimeType' => $file->getMimeType(),
                'size' => $uploadResult['meta']['size'],
                'width' => $uploadResult['meta']['width'],
                'height' => $uploadResult['meta']['height'],
                'userFileUuid' => $userFile->uuid,
                'variants' => $uploadResult['variants'], // Include all variants
                'uuid' => $uploadResult['uuid'],
            ];
        }

        $userFileUuids = array_column($results, 'userFileUuid');
        try {
            app(\App\Services\ActivityLog\ActivityLogService::class)->log(
                count($results) === 1 ? 'image_uploaded' : 'images_uploaded',
                null,
                count($results) === 1 ? 'Image uploaded' : 'Images uploaded',
                ['count' => count($results), 'user_file_uuids' => $userFileUuids],
                $request->user(),
                $request
            );
        } catch (\Throwable $e) {
            Log::warning('Failed to log image upload activity', ['error' => $e->getMessage()]);
        }

        // Return single object if single file, array if multiple
        return ApiResponse::success(count($results) === 1 ? $results[0] : $results);
    }

    /**
     * Store file information in user_files table
     */
    protected function storeUserFile(string $userUuid, $file, array $uploadResult, ?string $purpose = null): UserFile
    {
        // Use original variant URL as the primary URL
        $primaryUrl = $uploadResult['variants']['original']
            ?? $uploadResult['variants']['large']
            ?? '';

        $totalSizeWithVariants = $uploadResult['meta']['total_size_with_variants'] ?? $uploadResult['meta']['size'];

        $metadata = [
            'uuid' => $uploadResult['uuid'],
            'variants' => $uploadResult['variants'],
            'variant_sizes' => $uploadResult['variant_sizes'] ?? [],
            'total_size_with_variants' => $totalSizeWithVariants,
            'provider' => config('upload.default_provider', 'local'),
        ];
        if ($purpose !== null) {
            $metadata['purpose'] = $purpose;
        }

        $userFile = UserFile::query()->create([
            'user_uuid' => $userUuid,
            'url' => $primaryUrl,
            'path' => 'uploads/images/'.$uploadResult['uuid'],
            'type' => 'image',
            'filename' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'size' => $uploadResult['meta']['size'],
            'width' => $uploadResult['meta']['width'],
            'height' => $uploadResult['meta']['height'],
            'metadata' => $metadata,
        ]);

        // Update cached storage only for files that count toward quota (e.g. not branding logo/favicon)
        if (! app(\App\Services\Storage\UserStorageService::class)->isExcludedFromStorage($purpose)) {
            $storageService = app(\App\Services\Storage\UserStorageService::class);
            $storageService->incrementStorage($userUuid, $totalSizeWithVariants);
        }

        return $userFile;
    }
}
