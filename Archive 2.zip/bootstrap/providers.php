<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\DatabaseServiceProvider::class,
    App\Providers\GlobalServicesProvider::class,
    App\Providers\TelescopeServiceProvider::class,
];
