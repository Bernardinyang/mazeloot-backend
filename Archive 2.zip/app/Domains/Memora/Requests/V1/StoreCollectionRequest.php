<?php

namespace App\Domains\Memora\Requests\V1;

use Illuminate\Foundation\Http\FormRequest;

class StoreCollectionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'status' => ['nullable', 'in:draft,active,archived'],
            'presetId' => ['nullable', 'uuid', 'exists:memora_presets,uuid'],
            'watermarkId' => ['nullable', 'uuid', 'exists:memora_watermarks,uuid'],
            'settings' => ['nullable', 'array'],
            'eventDate' => ['nullable', 'date'],
        ];
    }
}
