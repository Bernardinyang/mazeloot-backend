<?php

return [
    'slow_request_threshold_ms' => (float) env('SLOW_REQUEST_THRESHOLD_MS', 1000),
];
